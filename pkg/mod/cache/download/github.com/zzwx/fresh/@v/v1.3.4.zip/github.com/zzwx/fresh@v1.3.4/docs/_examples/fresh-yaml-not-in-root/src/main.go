package main

func main() {
	HelloWorld()
}
