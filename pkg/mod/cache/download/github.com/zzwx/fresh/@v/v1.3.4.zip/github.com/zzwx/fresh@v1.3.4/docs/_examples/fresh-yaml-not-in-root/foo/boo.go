package foo

import "fmt"

//Boo print boo
func Boo() {
	fmt.Println("Boo")
}
