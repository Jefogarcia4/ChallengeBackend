package main

import "fmt"

//HelloWorld say Hello World
func HelloWorld() {
	fmt.Println("Hello World")
}
