package main

import "fmt"

func main() {
	//HelloWorld
	helloWorld()
}

func helloWorld() {
	fmt.Println("Hello World")
}
