//go:build windows
// +build windows

package runner

func initLimit() {
}
